const express=require('express');
const mongoose=require('mongoose')
const User=require('./models/User')
var CryptoJS = require("crypto-js");
const jwt=require('jsonwebtoken')
const verify=require('./verifyToken')
const Movie=require('./models/Movie')
const List=require('./models/List')
const cors=require('cors')

 const app=express();


const connectToDB=async()=>{
    await mongoose.connect('mongodb://localhost:27017/OTTdb',()=>{
    console.log('DB connected succesfully')

});
}

connectToDB();
app.use(express.json());
app.use(cors());

//Register......................................................

app.post('/register',async(req,res)=>{
    try {
        const {username,email}=req.body
        
        
        const newUser=new User({
            username,
            email,
            password:CryptoJS.AES.encrypt(req.body.password, 'king').toString()
            
            
        })
        const user= await newUser.save()
        res.status(200).json({success:true,user});
        
        
    } catch (error) {
        console.log(error)
        
    }
});


//Login..............................................
app.post('/login',async(req,res)=>{
    const {email}=req.body
    try {
        const user= await User.findOne({email})
        if(!user){
            res.status(404).json({success:false,error:' User not found please register'})
        }
        const bytes  = CryptoJS.AES.decrypt(user.password, 'king');
        const originalPassword = bytes.toString(CryptoJS.enc.Utf8);
        if(req.body.password!==originalPassword){
            res.status(400).json({success:false,error:'invalid Password'})
        }
        const accessToken=jwt.sign({id:user._id,isAdmin:user.isAdmin},'king',{expiresIn:'1d'})

        const {password,...info}=user._doc;


        res.status(200).json({success:true,...info,accessToken,mesg:'succesfully logged in'});
        
    } catch (error) {
        console.log(error);
        res.status(500).json({error})
        
    }
})

//Update.....................
app.put('/updateuser/:id',verify,async(req,res)=>{
    if(req.user.id === req.params.id || req.user.isAdmin){
        if(req.body.password){
            req.body.password=CryptoJS.AES.encrypt(req.body.password, 'king').toString()
        }
        try {
            const updatedUser=await User.findByIdAndUpdate(req.params.id,{$set:req.body},{new:true})
            res.status(200).json({success:true,updatedUser})
            
        } catch (error) {
            console.log(error);
            res.status(500).json(error)
            
        }

    }else{
        req.status(403).json('you can update only your account')
    }
})

//Delete..............................................................
app.delete('/deleteuser/:id',verify,async(req,res)=>{
    if(req.user.id === req.params.id || req.user.isAdmin){
        
        try {
            await User.findByIdAndDelete(req.params.id)
            res.status(200).json({success:true,msg:'user has been deleted.....'})
            
        } catch (error) {
            console.log(error);
            res.status(500).json(error)
            
        }

    }else{
        req.status(403).json('you can delete only your account')
    }

})

//GET....................................................
app.get('/finduser/:id',async(req,res)=>{
    try {
         const user_x= await User.findById(req.params.id)
         const {password,...info}=user_x._doc;
         res.status(200).json(info)

        
    } catch (error) {
        console.log(error);
        res.status(400).json(error)
        
    }
});


//GET ALL USERS ............................
app.get('/allusers',verify,async(req,res)=>{
    const query=req.query.new
    if(req.user.isAdmin){
        try {
            const allusers= query ? await User.find().sort({_id:-1}).limit(1) : await User.find();
            //const {password,...info}=allusers._doc;
            res.status(200).json(allusers)
            
        } catch (error) {
            console.log(error);
            
        }
    }else{
        res.status(403).json("you are not allowed to see all the users")
    }
    
});


//Get STATS................................................................

app.get('/userstats',async(req,res)=>{
    const today = new Date();
  const latYear = today.setFullYear(today.setFullYear() - 1);

  const monthArray=[
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
  ];

  try {
    const data = await User.aggregate([
      {
        $project: {
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: "$month",
          total: { $sum: 1 },
        },
      },
    ]);
    res.status(200).json(data)
  } catch (err) {
    res.status(500).json(err);
  }
})

///Movie Routes...........................................................

app.post("/addmovie", verify, async (req, res) => {
    if (req.user.isAdmin) {
      const newMovie = new Movie(req.body);
      try {
        const savedMovie = await newMovie.save();
        res.status(201).json(savedMovie);
      } catch (err) {
        res.status(500).json(err);
      }
    } else {
      res.status(403).json("You are not allowed!");
    }
  });
  
  //UPDATE
  
  app.put("/updatemovie/:id", verify, async (req, res) => {
    if (req.user.isAdmin) {
      try {
        const updatedMovie = await Movie.findByIdAndUpdate(
          req.params.id,
          {
            $set: req.body,
          },
          { new: true }
        );
        res.status(200).json(updatedMovie);
      } catch (err) {
        res.status(500).json(err);
      }
    } else {
      res.status(403).json("You are not allowed!");
    }
  });
  
  //DELETE
  
  app.delete("/deletemovie/:id", verify, async (req, res) => {
    if (req.user.isAdmin) {
      try {
        await Movie.findByIdAndDelete(req.params.id);
        res.status(200).json("The movie has been deleted...");
      } catch (err) {
        res.status(500).json(err);
      }
    } else {
      res.status(403).json("You are not allowed!");
    }
  });
  
  //GET
  
  app.get("/findmovie/:id", verify, async (req, res) => {
    try {
      const movie = await Movie.findById(req.params.id);
      res.status(200).json(movie);
    } catch (err) {
      res.status(500).json(err);
    }
  });
  
  //GET RANDOM
  
  app.get("/randommovie", verify, async (req, res) => {
    const type = req.query.type;
    let movie;
    try {
      if (type === "series") {
        movie = await Movie.aggregate([
          { $match: { isSeries: true } },
          { $sample: { size: 1 } },
        ]);
      } else {
        movie = await Movie.aggregate([
          { $match: { isSeries: false } },
          { $sample: { size: 1 } },
        ]);
      }
      res.status(200).json(movie);
    } catch (err) {
      res.status(500).json(err);
    }
  });
  
  //GET ALL
  
  app.get("/allmovies", verify, async (req, res) => {
    if (req.user.isAdmin) {
      try {
        const movies = await Movie.find();
        res.status(200).json(movies.reverse());
      } catch (err) {
        res.status(500).json(err);
      }
    } else {
      res.status(403).json("You are not allowed!");
    }
  });

///////LIST ROUTES.............................................................

//CREATE

app.post("/addlist", verify, async (req, res) => {
  if (req.user.isAdmin) {
    const newList = new List(req.body);
    try {
      const savedList = await newList.save();
      res.status(201).json(savedList);
    } catch (err) {
      res.status(500).json(err);
    }
  } else {
    res.status(403).json("You are not allowed!");
  }
});

//DELETE

app.delete("/deletelist/:id", verify, async (req, res) => {
  if (req.user.isAdmin) {
    try {
      await List.findByIdAndDelete(req.params.id);
      res.status(201).json("The list has been delete...");
    } catch (err) {
      res.status(500).json(err);
    }
  } else {
    res.status(403).json("You are not allowed!");
  }
});

//GET

app.get("/lists", verify, async (req, res) => {
  const typeQuery = req.query.type;
  const genreQuery = req.query.genre;
  let list = [];
  try {
    if (typeQuery) {
      if (genreQuery) {
        list = await List.aggregate([
          { $sample: { size: 10 } },
          { $match: { type: typeQuery, genre: genreQuery } },
        ]);
      } else {
        list = await List.aggregate([
          { $sample: { size: 10 } },
          { $match: { type: typeQuery } },
        ]);
      }
    } else {
      list = await List.aggregate([{ $sample: { size: 10 } }]);
    }
    res.status(200).json(list);
  } catch (err) {
    res.status(500).json(err);
  }
});









 app.listen(7000,()=>{
     console.log("Server running on port 7000...");
 })