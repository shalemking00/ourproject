// const express=require('express')
// const router=express.Router();
// const User=require('../models/User');


// //Register

// router.post('/register',async(req,res)=>{
    
//     try {
//         const {username,email,password}=req.body
        
//         const newUser=new User({
//             username,
//             email,
//             password,
            
//         })
//         const user= await newUser.save()
//         res.status(200).json({success:true,user});
//         next();
        
//     } catch (error) {
//         console.log(error)
        
//     }
// })